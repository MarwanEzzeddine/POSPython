exports.contacts='[{"name":"bla bla", "email":bla bla, "address":"bla bla"}]';
