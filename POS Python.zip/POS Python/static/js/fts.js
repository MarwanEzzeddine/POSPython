exports.CurrentDateTime = function () {
    var d = new Date();
    return d;
};

exports.myHashElement = function () {
    var varJSON = { "name": "hallo", "category": "world" };
    return varJSON;
}

