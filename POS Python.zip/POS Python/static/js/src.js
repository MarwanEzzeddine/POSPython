
function loadCategories(data) {
    var output = "";
    for (var i = 0; i < data.length; i++) {
        output += "<input type=button class=btn id=' + data[i].name + ' onclick=setItem('" + data[i].name + "','" + data[i].preis + "') value=" + data[i].name + " ></button>";
        document.getElementById("products").innerHTML = output;
    }
}
function setItem(name, preis) {
    
    var table = document.getElementById("items");
    var row = table.insertRow();
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    cell1.innerHTML = "<input type=text id=name name=name value="+ name +">";
    cell2.innerHTML = "<input type=number id=preis name=preis value=" + preis + ">";
    cell3.innerHTML = "<input type=number id=quantity name=quantity data-mydata=" + preis + " onchange=changeSum(this.value,dataset.mydata) min=1 max=5 value=1>";
    cell4.innerHTML = "<button class=button6 id=deleteItem data-mydata=" + preis + " onclick=deleteItem(this,this.dataset.mydata)>X</button>";
    document.getElementById("summe").value = parseFloat(document.getElementById("summe").value) + parseFloat(preis);
}
function deleteItem(r, preis) {
    alert("Delete?");
    var i = r.parentNode.parentNode.rowIndex;
    document.getElementById("items").deleteRow(i);
    document.getElementById("summe").value = parseFloat(document.getElementById("summe").value) - parseFloat(preis);
}
function changeSum(quantity, preis) {
    document.getElementById("summe").value = parseFloat(document.getElementById("summe").value) + parseFloat(preis);
}
