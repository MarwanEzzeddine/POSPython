from flask import Flask, render_template, request, jsonify
import json
import os
import pdb
from datetime import datetime
import random

class read_write_JSON:
    def __init__(self, file_name):
        self.file_name = file_name
    def readJSON(self):
        with open(self.file_name) as json_file:
            data: object = json.load(json_file)
        return data
read_write_Data = read_write_JSON('data.json')
data = read_write_Data.readJSON()

openObjects = []

app = Flask(__name__)
app.secret_key = 'secretkey'
app.tablenb = {"101", "102", "103", "104", "105"}

@app.route('/home')
def home():
    return render_template('project1.html', test="test: test")

@app.route('/booking')
def booking():
    return render_template('project1.html', test_booking="test_booking")

@app.route('/pos')
def showData():
    
    #print(request.args)
    #print(request.get_data())
    #print(request.data)

    #print(request.method)
    #print(request.path)
    #print(request.full_path)
    return render_template('project1.html', data=data, tablenb=["pizza", "pasta", "salat", "coffee", "beer"])

@app.route('/openObject')
def openObject():
    app.tablenb["101"].append({"name": "productname", "preis": "productpreis", "quantity": "productquantity"})
    print(app.tablenb[0])
    return render_template('project1.html', test="test: test")


@app.route('/bill', methods=['POST'])
def set_bill():
    random_nb = random.randint(1000, 9999)
    date_bill = datetime.now()
    json_bill = []
    json_element = []
    #print(request.method)
    #print(request.path)
    #print(request.args)
    #print(request.get_data())
    #print(request.data)
    data_bill= request.get_data().decode('utf-8').split('&')
    print(random_nb)
    print(date_bill.strftime("%d/%m/%Y %H:%M:%S"))
    json_element.append({"Bill / ID": random_nb})
    json_element.append({"Date / Time": date_bill.strftime("%d/%m/%Y / %H:%M:%S")})
    #test = data_bill[0].split('=')
    #print(test)
    #json_bill[test[0]] = test[1]
    for element in data_bill:
        e = element.split('=')
        json_element.append({e[0]: e[1]})
    print(json_element)
    bill_name = str(random_nb) + str(date_bill.strftime("%d/%m/%Y"))
    #print(request.form.getlist('name'))
    #print(request.form.get('name'))
    #print(request.form.get('preis'))
    #print(request.form.get('quantity'))
    print("Directory ", 'bill',  " Created ")
    bill_base_folder = 'bill'
    if not os.path.exists(bill_base_folder):
        os.mkdir(bill_base_folder)
    if not os.path.exists(bill_base_folder+"/"+date_bill.strftime("%Y")):
        os.mkdir(bill_base_folder+"/"+date_bill.strftime("%Y"))
    if not os.path.exists(bill_base_folder+"/"+date_bill.strftime("%Y")+"/"+date_bill.strftime("%m")):
        os.mkdir(bill_base_folder+"/"+date_bill.strftime("%Y") +
                 "/"+date_bill.strftime("%m"))
    if not os.path.exists(bill_base_folder+"/"+date_bill.strftime("%Y")+"/"+date_bill.strftime("%m")+"/"+date_bill.strftime("%d")):
        os.mkdir(bill_base_folder+"/"+date_bill.strftime("%Y") +
                 "/"+date_bill.strftime("%m")+"/"+date_bill.strftime("%d"))

    with open(bill_base_folder+"/"+date_bill.strftime("%Y")+"/"+date_bill.strftime("%m")+"/"+date_bill.strftime("%d")+"/"+str(random_nb)+'.json', 'w') as jsonfile:
        json.dump(json_element, jsonfile)
    return render_template('project1.html', test="test: test")
    
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8000, debug=True)
